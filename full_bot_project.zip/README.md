
Полностью готовый Telegram‑бот для Render.

1. Загрузите проект в GitHub  
2. Создайте Web Service в Render  
3. Укажите переменную окружения BOT_TOKEN  
4. После запуска выполните команду:  
   https://api.telegram.org/bot<ТОКЕН>/setWebhook?url=<URL>/webhook

Готово.
